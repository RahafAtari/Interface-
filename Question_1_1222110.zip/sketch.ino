#define DATA_MASK 0xF0   // pins D4 to D7
#define RS_BIT (1 << PB0)
#define EN_BIT (1 << PB1)

unsigned long lastSecond = 0;
unsigned int secondsCount = 0;

// function for waiting in microseconds
void wait_us(unsigned long us) {
  unsigned long start = micros();

  while (micros() - start < us) {
    // just wait
  }
}

// enable pulse for lcd
void lcd_pulse_en() {
  PORTB |= EN_BIT;

  __asm__ __volatile__("nop\n nop\n nop\n nop\n");

  PORTB &= ~EN_BIT;
}

// send 4 bits to lcd
void lcd_send_nibble(uint8_t nib) {
  PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);

  lcd_pulse_en();
}

// send full byte
void lcd_send(uint8_t byte, uint8_t rs) {

  if (rs == 1) {
    PORTB |= RS_BIT;
  }
  else {
    PORTB &= ~RS_BIT;
  }

  // send high nibble
  lcd_send_nibble(byte & 0xF0);

  // send low nibble
  lcd_send_nibble((byte << 4) & 0xF0);

  wait_us(50);
}

// send command
void lcd_command(uint8_t cmd) {

  lcd_send(cmd, 0);

  // clear and home need longer delay
  if (cmd == 0x01 || cmd == 0x02) {
    wait_us(2000);
  }
}

// send data
void lcd_data(uint8_t data) {
  lcd_send(data, 1);
}

// lcd initialization
void lcd_init() {

  // make lcd pins output
  DDRB |= RS_BIT | EN_BIT;
  DDRD |= DATA_MASK;

  // start with low
  PORTB &= ~(RS_BIT | EN_BIT);

  // wait after power on
  wait_us(50000);

  // initialization sequence
  lcd_send_nibble(0x30);
  wait_us(5000);

  lcd_send_nibble(0x30);
  wait_us(150);

  lcd_send_nibble(0x30);
  wait_us(150);

  // change to 4-bit mode
  lcd_send_nibble(0x20);
  wait_us(150);

  lcd_command(0x28); // 4 bit and 2 line
  lcd_command(0x0C); // display on
  lcd_command(0x06); // cursor move right
  lcd_command(0x01); // clear screen
}

// move cursor
void lcd_setCursor(uint8_t col, uint8_t row) {

  uint8_t address;

  if (row == 0) {
    address = col;
  }
  else {
    address = 0x40 + col;
  }

  lcd_command(0x80 | address);
}

// print string
void lcd_print(const char *s) {

  while (*s) {
    lcd_data(*s);
    s++;
  }
}

void setup() {

  lcd_init();

  lcd_setCursor(0, 0);

  lcd_print("Rahaf ID:1222110");
}

void loop() {

  unsigned long now = millis();

  // every second increase counter
  if (now - lastSecond >= 1000) {

    lastSecond = now;

    secondsCount++;

    lcd_setCursor(0, 1);

    lcd_print("Seconds:        ");

    lcd_setCursor(9, 1);

    char buffer[6];

    sprintf(buffer, "%u", secondsCount);

    lcd_print(buffer);
  }
}