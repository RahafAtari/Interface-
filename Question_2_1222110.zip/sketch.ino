#define LED_A (1 << PB0)   // pin 8
#define LED_B (1 << PB1)   // pin 9
#define LED_C (1 << PB2)   // pin 10
#define LED_D (1 << PB3)   // pin 11
#define LED_BONUS (1 << PB4) // pin 12

#define BUTTON (1 << PD2) // pin 2

uint32_t prevA = 0;
uint32_t prevB = 0;
uint32_t prevC = 0;
uint32_t prevSerial = 0;

uint32_t lastButtonTime = 0;

const uint32_t PERIOD_A = 500;
const uint32_t PERIOD_B = 300;
const uint32_t PERIOD_C = 750;

const uint32_t DEBOUNCE_TIME = 50;

bool lastButtonState = HIGH;

void setup() {

  Serial.begin(9600);

  // set leds as outputs
  DDRB |= LED_A | LED_B | LED_C | LED_D | LED_BONUS;

  // set button as input
  DDRD &= ~BUTTON;

  // enable pull up resistor
  PORTD |= BUTTON;

  // initial states
  PORTB &= ~(LED_A | LED_B | LED_D | LED_BONUS);

  PORTB |= LED_C;
}

void loop() {

  uint32_t now = millis();

  // LED A blink every 500 ms
  if (now - prevA >= PERIOD_A) {

    prevA = now;

    PORTB ^= LED_A;
  }

  // LED B blink every 300 ms
  if (now - prevB >= PERIOD_B) {

    prevB = now;

    PORTB ^= LED_B;
  }

  // LED C blink every 750 ms
  if (now - prevC >= PERIOD_C) {

    prevC = now;

    PORTB ^= LED_C;
  }

  // read button state
  bool buttonState;

  if (PIND & BUTTON) {
    buttonState = HIGH;
  }
  else {
    buttonState = LOW;
  }

  // when button pressed
  if (lastButtonState == HIGH && buttonState == LOW) {

    if (now - lastButtonTime >= DEBOUNCE_TIME) {

      PORTB ^= LED_D;

      lastButtonTime = now;
    }
  }

  lastButtonState = buttonState;

  // bonus led works if A B C are all ON
  if ((PORTB & (LED_A | LED_B | LED_C)) == (LED_A | LED_B | LED_C)) {

    PORTB |= LED_BONUS;
  }
  else {

    PORTB &= ~LED_BONUS;
  }

  // print states every 2 seconds
  if (now - prevSerial >= 2000) {

    prevSerial = now;

    Serial.print("A=");
    Serial.print((PORTB & LED_A) ? 1 : 0);

    Serial.print(" B=");
    Serial.print((PORTB & LED_B) ? 1 : 0);

    Serial.print(" C=");
    Serial.print((PORTB & LED_C) ? 1 : 0);

    Serial.print(" D=");
    Serial.println((PORTB & LED_D) ? 1 : 0);
  }
}