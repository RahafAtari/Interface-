#include <Arduino.h>
#include <stdio.h>

#define DATA_MASK 0xF0

#define RS_BIT (1 << PB0) // D8
#define EN_BIT (1 << PB1) // D9

#define LED1_PIN 10
#define LED2_PIN 11

#define BUTTON_BIT (1 << PD2) // D2

// simple timer structure
struct SimpleTimer {

  unsigned long interval;
  unsigned long lastFired;

  void (*callback)();

  bool active;

  void every(unsigned long ms, void (*cb)()) {

    interval = ms;

    lastFired = millis();

    callback = cb;

    active = true;
  }

  void update() {

    if (!active) return;

    unsigned long now = millis();

    if (now - lastFired >= interval) {

      lastFired = now;

      callback();
    }
  }
};

// oscillator timer
struct OscTimer {

  unsigned long halfPeriod;

  unsigned long lastToggle;

  uint8_t pin;

  bool active;

  void oscillate(uint8_t p, unsigned long ms, uint8_t startState) {

    pin = p;

    halfPeriod = ms;

    lastToggle = millis();

    digitalWrite(pin, startState);

    active = true;
  }

  void update() {

    if (!active) return;

    if (millis() - lastToggle >= halfPeriod) {

      lastToggle = millis();

      digitalWrite(pin, !digitalRead(pin));
    }
  }
};

// pulse timer
struct PulseTimer {

  unsigned long duration;

  unsigned long startTime;

  uint8_t pin;

  bool active;

  void pulse(uint8_t p, unsigned long ms, uint8_t activeState) {

    pin = p;

    duration = ms;

    startTime = millis();

    digitalWrite(pin, activeState);

    active = true;
  }

  void update() {

    if (!active) return;

    if (millis() - startTime >= duration) {

      digitalWrite(pin, LOW);

      active = false;
    }
  }
};

OscTimer t1;

PulseTimer t2;

SimpleTimer t3, t4, t5;

volatile unsigned int ticks = 0;

unsigned long pulseEndTime = 0;

// bonus mode
bool fastMode = false;

unsigned long fastModeStart = 0;

unsigned long lastButtonPress = 0;

bool lastButtonState = HIGH;

// ---------------- LCD FUNCTIONS ----------------

void wait_us(unsigned long us) {

  unsigned long start = micros();

  while (micros() - start < us) {
    // wait
  }
}

void lcd_pulse_en() {

  PORTB |= EN_BIT;

  __asm__ __volatile__("nop\n nop\n nop\n nop\n");

  PORTB &= ~EN_BIT;
}

void lcd_send_nibble(uint8_t nib) {

  PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);

  lcd_pulse_en();
}

void lcd_send(uint8_t byte, uint8_t rs) {

  if (rs) {
    PORTB |= RS_BIT;
  }
  else {
    PORTB &= ~RS_BIT;
  }

  lcd_send_nibble(byte & 0xF0);

  lcd_send_nibble((byte << 4) & 0xF0);

  wait_us(50);
}

void lcd_command(uint8_t cmd) {

  lcd_send(cmd, 0);

  if (cmd == 0x01 || cmd == 0x02) {

    wait_us(2000);
  }
}

void lcd_data(uint8_t data) {

  lcd_send(data, 1);
}

void lcd_init() {

  DDRB |= RS_BIT | EN_BIT;

  DDRD |= DATA_MASK;

  PORTB &= ~(RS_BIT | EN_BIT);

  wait_us(50000);

  lcd_send_nibble(0x30);

  wait_us(5000);

  lcd_send_nibble(0x30);

  wait_us(150);

  lcd_send_nibble(0x30);

  wait_us(150);

  lcd_send_nibble(0x20);

  wait_us(150);

  lcd_command(0x28);

  lcd_command(0x0C);

  lcd_command(0x06);

  lcd_command(0x01);
}

void lcd_setCursor(uint8_t col, uint8_t row) {

  uint8_t address;

  if (row == 0) {
    address = col;
  }
  else {
    address = 0x40 + col;
  }

  lcd_command(0x80 | address);
}

void lcd_print(const char *s) {

  while (*s) {

    lcd_data(*s);

    s++;
  }
}

// ---------------- CALLBACKS ----------------

void countTick() {

  ticks++;
}

void triggerPulse() {

  t2.pulse(LED2_PIN, 100, HIGH);

  pulseEndTime = millis() + 100;
}

void updateLCD() {

  char line0[17];

  lcd_setCursor(0, 0);

  sprintf(line0, "Ticks:%4u     ", ticks);

  lcd_print(line0);

  lcd_setCursor(0, 1);

  unsigned long now = millis();

  if (fastMode) {

    lcd_print("FAST MODE      ");
  }
  else if (now >= pulseEndTime && now < pulseEndTime + 200) {

    lcd_print("L1:osc L2:off ");
  }
  else {

    lcd_print("L1:osc L2:pulse");
  }
}

// ---------------- BUTTON ----------------

void checkBonusButton() {

  unsigned long now = millis();

  bool buttonState = (PIND & BUTTON_BIT) ? HIGH : LOW;

  // button pressed
  if (lastButtonState == HIGH && buttonState == LOW) {

    if (now - lastButtonPress >= 50) {

      lastButtonPress = now;

      if (!fastMode) {

        fastMode = true;

        fastModeStart = now;

        // faster timing
        t1.halfPeriod = 200;

        t3.interval = 1000;

        t4.interval = 500;

        t5.interval = 250;
      }
    }
  }

  lastButtonState = buttonState;

  // return to normal after 5 sec
  if (fastMode && now - fastModeStart >= 5000) {

    fastMode = false;

    t1.halfPeriod = 400;

    t3.interval = 2000;

    t4.interval = 1000;

    t5.interval = 500;
  }
}

// ---------------- SETUP ----------------

void setup() {

  pinMode(LED1_PIN, OUTPUT);

  pinMode(LED2_PIN, OUTPUT);

  digitalWrite(LED1_PIN, LOW);

  digitalWrite(LED2_PIN, LOW);

  // button input
  DDRD &= ~BUTTON_BIT;

  PORTD |= BUTTON_BIT;

  lcd_init();

  lcd_setCursor(0, 0);

  lcd_print("Ticks:   0     ");

  lcd_setCursor(0, 1);

  lcd_print("L1:osc L2:pulse");

  t1.oscillate(LED1_PIN, 400, HIGH);

  t3.every(2000, triggerPulse);

  t4.every(1000, countTick);

  t5.every(500, updateLCD);
}

void loop() {

  checkBonusButton();

  t1.update();

  t2.update();

  t3.update();

  t4.update();

  t5.update();
}