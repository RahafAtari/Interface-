#include <Arduino.h>
#include <stdio.h>
#include <avr/interrupt.h>

// LCD pins
#define DATA_MASK 0xF0

// LCD control pins
#define LCD_RS_BIT (1 << PC0) // A0
#define LCD_EN_BIT (1 << PC1) // A1

// Traffic LEDs
#define RED_BIT    (1 << PB0) // D8
#define YELLOW_BIT (1 << PB1) // D9
#define GREEN_BIT  (1 << PB2) // D10
#define PED_BIT    (1 << PB3) // D11

#define TRAFFIC_MASK (RED_BIT | YELLOW_BIT | GREEN_BIT)
#define ALL_LED_MASK (RED_BIT | YELLOW_BIT | GREEN_BIT | PED_BIT)

// Pedestrian button
#define PED_BUTTON_BIT (1 << PD2) // D2

// States
enum State {
  GREEN,
  YELLOW,
  RED,
  PED_CROSS
};

State state = GREEN;

unsigned long stateStart = 0;

const unsigned long GREEN_TIME = 5000;
const unsigned long YELLOW_TIME = 2000;
const unsigned long RED_TIME = 5000;
const unsigned long PED_TIME = 4000;

volatile bool pedRequest = false;

// ---------------- TIMER ----------------

struct SimpleTimer {
  unsigned long interval;
  unsigned long lastTime;
  void (*callback)();
  bool active;

  void every(unsigned long ms, void (*cb)()) {
    interval = ms;
    lastTime = millis();
    callback = cb;
    active = true;
  }

  void update() {
    if (!active) return;

    unsigned long now = millis();

    if (now - lastTime >= interval) {
      lastTime = now;
      callback();
    }
  }
};

struct BlinkTimer {
  unsigned long interval;
  unsigned long lastToggle;
  bool active;

  void start(unsigned long ms) {
    interval = ms;
    lastToggle = millis();
    active = true;
  }

  void stop() {
    active = false;
    PORTB &= ~PED_BIT;
  }

  void update() {
    if (!active) return;

    unsigned long now = millis();

    if (now - lastToggle >= interval) {
      lastToggle = now;
      PORTB ^= PED_BIT;
    }
  }
};

SimpleTimer lcdTimer;
BlinkTimer pedBlink;

// ---------------- LCD ----------------

void wait_us(unsigned long us) {
  unsigned long start = micros();

  while (micros() - start < us) {
  }
}

void lcd_pulse_en() {
  PORTC |= LCD_EN_BIT;

  __asm__ __volatile__("nop\n nop\n nop\n nop\n");

  PORTC &= ~LCD_EN_BIT;
}

void lcd_send_nibble(uint8_t nib) {
  PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);

  lcd_pulse_en();
}

void lcd_send(uint8_t value, uint8_t rs) {

  if (rs) {
    PORTC |= LCD_RS_BIT;
  }
  else {
    PORTC &= ~LCD_RS_BIT;
  }

  lcd_send_nibble(value & 0xF0);
  lcd_send_nibble((value << 4) & 0xF0);

  wait_us(50);
}

void lcd_command(uint8_t cmd) {
  lcd_send(cmd, 0);

  if (cmd == 0x01 || cmd == 0x02) {
    wait_us(2000);
  }
}

void lcd_data(uint8_t data) {
  lcd_send(data, 1);
}

void lcd_init() {

  DDRC |= LCD_RS_BIT | LCD_EN_BIT;

  DDRD |= DATA_MASK;

  PORTC &= ~(LCD_RS_BIT | LCD_EN_BIT);

  wait_us(50000);

  lcd_send_nibble(0x30);
  wait_us(5000);

  lcd_send_nibble(0x30);
  wait_us(150);

  lcd_send_nibble(0x30);
  wait_us(150);

  lcd_send_nibble(0x20);
  wait_us(150);

  lcd_command(0x28);
  lcd_command(0x0C);
  lcd_command(0x06);
  lcd_command(0x01);
}

void lcd_setCursor(uint8_t col, uint8_t row) {

  uint8_t address;

  if (row == 0) {
    address = col;
  }
  else {
    address = 0x40 + col;
  }

  lcd_command(0x80 | address);
}

void lcd_print(const char *text) {

  while (*text) {
    lcd_data(*text++);
  }
}

// ---------------- TRAFFIC LIGHT ----------------

void setTrafficLights(uint8_t lights) {

  PORTB = (PORTB & ~TRAFFIC_MASK) | (lights & TRAFFIC_MASK);
}

unsigned long getStateTime() {

  switch (state) {

    case GREEN:
      return GREEN_TIME;

    case YELLOW:
      return YELLOW_TIME;

    case RED:
      return RED_TIME;

    case PED_CROSS:
      return PED_TIME;
  }

  return GREEN_TIME;
}

void updateLCD() {

  unsigned long now = millis();

  unsigned long elapsed = now - stateStart;

  unsigned long duration = getStateTime();

  int remain = 0;

  if (elapsed < duration) {
    remain = (duration - elapsed + 999) / 1000;
  }

  lcd_setCursor(0, 0);

  switch (state) {

    case GREEN:
      lcd_print("GO              ");
      break;

    case YELLOW:
      lcd_print("SLOW            ");
      break;

    case RED:
      lcd_print("STOP            ");
      break;

    case PED_CROSS:
      lcd_print("CROSS           ");
      break;
  }

  char line[17];

  sprintf(line, "T:%2d s          ", remain);

  lcd_setCursor(0, 1);

  lcd_print(line);
}

void changeState(State newState) {

  state = newState;

  stateStart = millis();

  switch (state) {

    case GREEN:

      setTrafficLights(GREEN_BIT);

      pedBlink.stop();

      pedRequest = false;

      break;

    case YELLOW:

      setTrafficLights(YELLOW_BIT);

      pedBlink.stop();

      break;

    case RED:

      setTrafficLights(RED_BIT);

      pedBlink.stop();

      pedRequest = false;

      break;

    case PED_CROSS:

      setTrafficLights(RED_BIT);

      PORTB &= ~PED_BIT;

      pedBlink.start(250);

      pedRequest = false;

      break;
  }

  updateLCD();
}

// ---------------- INTERRUPT ----------------

ISR(INT0_vect) {

  pedRequest = true;
}

// ---------------- SETUP ----------------

void setup() {

  Serial.begin(9600);

  // LEDs output
  DDRB |= ALL_LED_MASK;

  // LEDs OFF
  PORTB &= ~ALL_LED_MASK;

  // Button input
  DDRD &= ~PED_BUTTON_BIT;

  // Pull-up resistor
  PORTD |= PED_BUTTON_BIT;

  lcd_init();

  // INT0 falling edge
  EICRA |= (1 << ISC01);
  EICRA &= ~(1 << ISC00);

  // Enable INT0
  EIMSK |= (1 << INT0);

  // Global interrupt enable
  sei();

  // LCD update every 1 second
  lcdTimer.every(1000, updateLCD);

  changeState(GREEN);
}

// ---------------- LOOP ----------------

void loop() {

  unsigned long now = millis();

  unsigned long elapsed = now - stateStart;

  switch (state) {

    case GREEN:

      if (elapsed >= GREEN_TIME) {

        if (pedRequest) {
          changeState(PED_CROSS);
        }
        else {
          changeState(YELLOW);
        }
      }

      break;

    case YELLOW:

      pedRequest = false;

      if (elapsed >= YELLOW_TIME) {
        changeState(RED);
      }

      break;

    case RED:

      pedRequest = false;

      if (elapsed >= RED_TIME) {
        changeState(GREEN);
      }

      break;

    case PED_CROSS:

      pedRequest = false;

      if (elapsed >= PED_TIME) {
        changeState(GREEN);
      }

      break;
  }

  lcdTimer.update();

  pedBlink.update();
}