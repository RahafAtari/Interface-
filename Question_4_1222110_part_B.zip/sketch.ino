#include <Arduino.h>
#include <stdio.h>
#include <avr/interrupt.h>

// LCD pins
#define DATA_MASK 0xF0

#define RS_BIT (1 << PB0) // D8
#define EN_BIT (1 << PB1) // D9

// buttons
#define BTN_INC_BIT   (1 << PD2) // D2
#define BTN_RESET_BIT (1 << PD3) // D3
#define BTN_PAUSE_BIT (1 << PC0) // A0

volatile uint16_t count = 0;

volatile bool changed = false;

volatile bool paused = false;

volatile uint32_t lastIncMS = 0;

volatile uint32_t lastResetMS = 0;

bool lastPauseBtn = HIGH;

uint32_t lastPauseMS = 0;

// ---------------- LCD FUNCTIONS ----------------

void wait_us(unsigned long us) {

  unsigned long start = micros();

  while (micros() - start < us) {
    // wait
  }
}

void lcd_pulse_en() {

  PORTB |= EN_BIT;

  __asm__ __volatile__("nop\n nop\n nop\n nop\n");

  PORTB &= ~EN_BIT;
}

void lcd_send_nibble(uint8_t nib) {

  PORTD = (PORTD & ~DATA_MASK) | (nib & DATA_MASK);

  lcd_pulse_en();
}

void lcd_send(uint8_t byte, uint8_t rs) {

  if (rs) {
    PORTB |= RS_BIT;
  }
  else {
    PORTB &= ~RS_BIT;
  }

  lcd_send_nibble(byte & 0xF0);

  lcd_send_nibble((byte << 4) & 0xF0);

  wait_us(50);
}

void lcd_command(uint8_t cmd) {

  lcd_send(cmd, 0);

  if (cmd == 0x01 || cmd == 0x02) {

    wait_us(2000);
  }
}

void lcd_data(uint8_t data) {

  lcd_send(data, 1);
}

void lcd_init() {

  DDRB |= RS_BIT | EN_BIT;

  DDRD |= DATA_MASK;

  PORTB &= ~(RS_BIT | EN_BIT);

  wait_us(50000);

  lcd_send_nibble(0x30);

  wait_us(5000);

  lcd_send_nibble(0x30);

  wait_us(150);

  lcd_send_nibble(0x30);

  wait_us(150);

  lcd_send_nibble(0x20);

  wait_us(150);

  lcd_command(0x28);

  lcd_command(0x0C);

  lcd_command(0x06);

  lcd_command(0x01);
}

void lcd_setCursor(uint8_t col, uint8_t row) {

  lcd_command(0x80 | (row ? 0x40 + col : col));
}

void lcd_print(const char *s) {

  while (*s) {

    lcd_data(*s);

    s++;
  }
}

// ---------------- LCD UPDATE ----------------

void updateLCD() {

  lcd_setCursor(0, 0);

  if (paused) {

    lcd_print("PAUSED          ");
  }
  else {

    char line[17];

    uint16_t snap;

    noInterrupts();

    snap = count;

    interrupts();

    sprintf(line, "Count:%5u     ", snap);

    lcd_print(line);
  }

  lcd_setCursor(0, 1);

  lcd_print("Rahaf 1222110 ");
}

// ---------------- INTERRUPTS ----------------

ISR(INT0_vect) {

  uint32_t now = millis();

  if (now - lastIncMS >= 50) {

    if (!paused) {

      count++;

      changed = true;
    }

    lastIncMS = now;
  }
}

ISR(INT1_vect) {

  uint32_t now = millis();

  if (now - lastResetMS >= 50) {

    count = 0;

    changed = true;

    lastResetMS = now;
  }
}

// ---------------- PAUSE BUTTON ----------------

void checkPauseButton() {

  bool state = (PINC & BTN_PAUSE_BIT) ? HIGH : LOW;

  uint32_t now = millis();

  if (lastPauseBtn == HIGH && state == LOW) {

    if (now - lastPauseMS >= 50) {

      paused = !paused;

      changed = true;

      lastPauseMS = now;
    }
  }

  lastPauseBtn = state;
}

// ---------------- SETUP ----------------

void setup() {

  Serial.begin(9600);

  // D2 and D3 input
  DDRD &= ~(BTN_INC_BIT | BTN_RESET_BIT);

  // enable pull up
  PORTD |= BTN_INC_BIT | BTN_RESET_BIT;

  // A0 input
  DDRC &= ~BTN_PAUSE_BIT;

  PORTC |= BTN_PAUSE_BIT;

  lcd_init();

  updateLCD();

  // falling edge INT0
  EICRA |= (1 << ISC01);

  EICRA &= ~(1 << ISC00);

  // falling edge INT1
  EICRA |= (1 << ISC11);

  EICRA &= ~(1 << ISC10);

  // enable interrupts
  EIMSK |= (1 << INT0) | (1 << INT1);

  // global interrupt enable
  sei();
}

// ---------------- LOOP ----------------

void loop() {

  checkPauseButton();

  if (changed) {

    uint16_t snap;

    bool pauseSnap;

    noInterrupts();

    snap = count;

    pauseSnap = paused;

    changed = false;

    interrupts();

    updateLCD();

    Serial.print("Count = ");

    Serial.print(snap);

    if (pauseSnap) {

      Serial.println(" [PAUSED]");
    }
    else {

      Serial.println();
    }
  }
}